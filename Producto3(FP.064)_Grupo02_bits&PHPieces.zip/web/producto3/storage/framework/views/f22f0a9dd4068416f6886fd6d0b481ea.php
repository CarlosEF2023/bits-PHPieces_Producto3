<select class="form-select" name="<?php echo e($name); ?>">
    <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($zona->id_zona); ?>" <?php echo e($selected == $zona->descripcion ? 'selected' : ''); ?>>
            <?php echo e($zona->descripcion); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH /var/www/html/producto3/resources/views/components/zona-select.blade.php ENDPATH**/ ?>