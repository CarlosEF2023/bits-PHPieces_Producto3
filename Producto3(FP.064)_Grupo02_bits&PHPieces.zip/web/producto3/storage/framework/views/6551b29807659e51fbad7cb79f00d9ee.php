<select class="form-select" name="<?php echo e($name); ?>">
    <?php $__currentLoopData = $viajeros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarioviajero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($usuarioviajero->email); ?>" <?php echo e($selected == $usuarioviajero->email ? 'selected' : ''); ?>>
            <?php echo e($usuarioviajero->email); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH /var/www/html/producto3/resources/views/components/viajero-select.blade.php ENDPATH**/ ?>