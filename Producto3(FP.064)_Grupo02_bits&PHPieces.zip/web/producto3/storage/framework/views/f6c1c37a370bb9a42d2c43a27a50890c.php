
<?php $__env->startSection('title', 'Menú de listado de reservas'); ?>

<?php $__env->startSection("nav"); ?>
<?php echo $__env->make('layouts.menu_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Hotel</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/producto3/resources/views/hotel/index.blade.php ENDPATH**/ ?>