<select class="form-select" name="<?php echo e($name); ?>">
    <?php $__currentLoopData = $hoteles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($hotel->id_hotel); ?>" <?php echo e($selected == $hotel->id_hotel ? 'selected' : ''); ?>>
            <?php echo e($hotel->NombreHotel); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH /var/www/html/producto3/resources/views/components/hotel-select.blade.php ENDPATH**/ ?>