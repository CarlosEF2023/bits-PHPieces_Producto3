
<?php $__env->startSection('title', 'Reservas del Hotel all Aeropuerto'); ?>

<?php $__env->startSection('content'); ?>

<table class="table table-striped table-hover">

<thead>
    <tr>
        <th>Localizador</th>
        <th>Tipo reserva</th>
        <th>Recoger en</th>
        <th>Fecha de recogida</th>
        <th>Hora de recogida</th>
        <th>Destino</th>
        <th>Usuario</th>
        <th>Número viajeros</th>
    </tr>
</thead>
<tbody>

<div id="containerVer">

<?php $__currentLoopData = $listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <?php switch($data['id_tipo_reserva']):
            case (1): ?>
                <!-- Aeropuerto -> Hotel -->
                <th><?php echo e($data['localizador']); ?></th>
                <td><?php echo e($data['Descripción']); ?></td>
                <td><?php echo e($data['origen_vuelo_entrada']); ?> / <?php echo e($data['numer_vuelo_entrada']); ?></td>
                <td><?php echo e($data['fecha_entrada']); ?></td>
                <td><?php echo e($data['hora_entrada']); ?></td>
                <td><?php echo e($data['NombreHotel']); ?></td>
                <td><?php echo e($data['email_cliente']); ?></td>
                <td><?php echo e($data['num_viajeros']); ?></td>
                <?php break; ?>

            <?php case (2): ?>
                <!-- Hotel -> Aeropuerto -->
                <th><?php echo e($data['localizador']); ?></th>
                <td><?php echo e($data['Descripción']); ?></td>
                <td><?php echo e($data['NombreHotel']); ?></td>
                <td><?php echo e($data['fecha_vuelo_salida']); ?></td>
                <td><?php echo e($data['hora_recogida_hotel']); ?></td>
                <td><?php echo e($data['origen_vuelo_entrada']); ?></td>
                <td><?php echo e($data['email_cliente']); ?></td>
                <td><?php echo e($data['num_viajeros']); ?></td>
                <?php break; ?>

            <?php case (3): ?>
                <!-- Completo -->
                <th><?php echo e($data['localizador']); ?></th>
                <td><?php echo e($data['Descripción']); ?></td>
                <td><?php echo e($data['origen_vuelo_entrada']); ?> / <?php echo e($data['numer_vuelo_entrada']); ?></td>
                <td><?php echo e($data['fecha_entrada']); ?></td>
                <td><?php echo e($data['hora_entrada']); ?></td>
                <td><?php echo e($data['NombreHotel']); ?></td>
                <td><?php echo e($data['email_cliente']); ?></td>
                <td><?php echo e($data['num_viajeros']); ?></td>
                </tr><tr>
                <th><?php echo e($data['localizador']); ?></th>
                <td><?php echo e($data['Descripción']); ?></td>
                <td><?php echo e($data['NombreHotel']); ?></td>
                <td><?php echo e($data['fecha_vuelo_salida']); ?></td>
                <td><?php echo e($data['hora_recogida_hotel']); ?></td>
                <td><?php echo e($data['origen_vuelo_entrada']); ?></td>
                <td><?php echo e($data['origen_vuelo_entrada']); ?></td>
                <td><?php echo e($data['email_cliente']); ?></td>
                <td><?php echo e($data['num_viajeros']); ?></td>
                <?php break; ?>
        <?php endswitch; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</tbody>

</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/producto3/resources/views/reservas/listados/ver_itinerario.blade.php ENDPATH**/ ?>