
<?php $__env->startSection('title', 'Reservas del Aeropuerto al Hotel'); ?>

<?php $__env->startSection('content'); ?>

<form method="POST" name="checkout-form" id="checkout-form" action="<?php echo e(Route(Session::get('userroute').'.reservas.mod')); ?>">
<?php echo csrf_field(); ?>   
<?php echo method_field('PUT'); ?> 
<input type="hidden" name="idtiporeserva" id="idtiporeserva" value="1">
<input name="id_reserva" id="id_reserva" type="hidden" VALUE="<?php echo e($reservas->id_reserva); ?>" \>
<div class="row justify-content-center mt-5">
    <div class="col-md-8">
    <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h1 class="card-title mb-0">MODIFICAR LOCALIZADOR: <?php echo e($reservas->localizador); ?></h1>
        <a href="<?php echo e(back()->getTargetUrl()); ?>" class="btn btn-primary">Volver</a>
    </div>
    <div class="card-body">

<h3 class="card-title">Recogida aeropuerto</h3>
<div class="input-group mb-4">
<span class="input-group-text">Día de llegada</span>
    <input class="form-control" name="diadellegada" id="diadellegada" type="date" VALUE="<?php echo e($reservas->fecha_entrada); ?>" \>
</div>
<div class="input-group mb-4">
<span class="input-group-text">Hora de llegada</span>
    <input class="form-control" name="horadellegada" id="horadellegada" type="time" VALUE="<?php echo e($reservas->hora_entrada); ?>" \>
</div>
<div class="input-group mb-4">
<span class="input-group-text">Número de vuelo</span>
    <input class="form-control" name="numerovuelo" id="numerovuelo" type="text" VALUE="<?php echo e($reservas->numero_vuelo_entrada); ?>" \>
</div>
<div class="input-group mb-4">
<span class="input-group-text">Aeropueto Origen</span>
    <input class="form-control" name="aeropuertoorigen" id="aeropuertoorigen" type="text" VALUE="<?php echo e($reservas->origen_vuelo_entrada); ?>" \>
</div>
<!-- PARTE COMÚN -->
<h3 class="card-title">Hotel destino</h3>
<div class="input-group mb-4">
<span class="input-group-text">Hotel recogida</span>
    <?php if (isset($component)) { $__componentOriginal49377d3340038425e59f0e6f1b90a6b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49377d3340038425e59f0e6f1b90a6b2 = $attributes; } ?>
<?php $component = App\View\Components\HotelSelect::resolve(['selected' => $reservas->id_destino,'name' => 'Hotel_Destino'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hotel-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HotelSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49377d3340038425e59f0e6f1b90a6b2)): ?>
<?php $attributes = $__attributesOriginal49377d3340038425e59f0e6f1b90a6b2; ?>
<?php unset($__attributesOriginal49377d3340038425e59f0e6f1b90a6b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49377d3340038425e59f0e6f1b90a6b2)): ?>
<?php $component = $__componentOriginal49377d3340038425e59f0e6f1b90a6b2; ?>
<?php unset($__componentOriginal49377d3340038425e59f0e6f1b90a6b2); ?>
<?php endif; ?> 
</div>
<div class="input-group mb-4">
<span class="input-group-text">Número de viajeros</span>
    <input class="form-control" name="numeroviajeros" id="numeroviajeros" type="number" min="1" max="8" VALUE="<?php echo e($reservas->num_viajeros); ?>" \>
</div>
<div class="input-group mb-4">
        <span class="input-group-text">email reserva</span>
        <?php if(Session::get('usertype')!="6"): ?>
            <?php if (isset($component)) { $__componentOriginalab1a3c71002c606abd41b37b443176e0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab1a3c71002c606abd41b37b443176e0 = $attributes; } ?>
<?php $component = App\View\Components\ViajeroSelect::resolve(['selected' => $reservas->email_cliente,'name' => 'emailreserva'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('viajero-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ViajeroSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab1a3c71002c606abd41b37b443176e0)): ?>
<?php $attributes = $__attributesOriginalab1a3c71002c606abd41b37b443176e0; ?>
<?php unset($__attributesOriginalab1a3c71002c606abd41b37b443176e0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab1a3c71002c606abd41b37b443176e0)): ?>
<?php $component = $__componentOriginalab1a3c71002c606abd41b37b443176e0; ?>
<?php unset($__componentOriginalab1a3c71002c606abd41b37b443176e0); ?>
<?php endif; ?>     
        <!-- <input name="emailreserva" id="emailreserva" type="mail" value=""> -->
        <?php else: ?>
            <input class="form-control" name="emailreserva" id="emailreserva" type="mail" value="<?php echo e($reservas->email_cliente); ?>">
        <?php endif; ?>
        </div>
        </div>
        <div class="card-foot text-center">
            <button type="submit" class="btn btn-primary" name="enviar" id="enviar" >Validar cambios</button>
            <a href="<?php echo e(back()->getTargetUrl()); ?>" class="btn btn-danger">Cancelar</a>
        </div>
        </div>
    </div>

</div>
</form>
<br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/producto3/resources/views//reservas/aeropuerto/modificar_reservaaeropuerto.blade.php ENDPATH**/ ?>