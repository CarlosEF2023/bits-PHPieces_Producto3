
<?php $__env->startSection('title', 'Listado de todas las reservas'); ?>

<?php $__env->startSection('content'); ?>

<br>
<h1>Listado de todas las reservas realizadas </h1>
<br>
<div class="card">
    <table class="table table-bordered table-striped table-hover">
        <thead class="table-dark" style="background: white;position: sticky;top: 0;box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);">
            <tr>
                <th>Localizador</th>
                <th>Tipo reserva</th>
                <th>usuario</th>
                <th>Fecha reserva</th>
                <th>Hotel</th>
                <th>Fecha Entrada</th>
                <th>Hora Entada</th>
                <th>Hora Recogida</th>
                <th>Aeropuerto</th>
                <th>Fecha Salida</th>
                <th>Hora Salida</th>
                <th colspan="3">Opciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $matrizresultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($info["localizador"]); ?></td>
                <td><?php echo e($info["Descripción"]); ?></td>
                <td><?php echo e($info["email_cliente"]); ?></td>
                <td><?php echo e($info["fecha_reserva"]); ?></td>
                <?php switch($info["id_tipo_reserva"]):
                    case ("1"): ?>
                        <td><?php echo e($info["NombreHotel"]); ?></td>
                        <td><?php echo e($info["fecha_entrada"]); ?></td>
                        <td><?php echo e($info["hora_entrada"]); ?></td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <?php break; ?>
                    <?php case ("2"): ?>
                        <td><?php echo e($info["NombreHotel"]); ?></td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td><?php echo e($info["hora_recogida_hotel"]); ?></td>
                        <td><?php echo e($info["origen_vuelo_entrada"]); ?></td>
                        <td><?php echo e($info["fecha_vuelo_salida"]); ?></td>
                        <td><?php echo e($info["hora_vuelo_salida"]); ?></td>
                        <?php break; ?>
                    <?php case ("3"): ?>
                        <td><?php echo e($info["NombreHotel"]); ?></td>
                        <td><?php echo e($info["fecha_entrada"]); ?></td>
                        <td><?php echo e($info["hora_entrada"]); ?></td>
                        <td><?php echo e($info["hora_recogida_hotel"]); ?></td>
                        <td><?php echo e($info["origen_vuelo_entrada"]); ?></td>
                        <td><?php echo e($info["fecha_vuelo_salida"]); ?></td>
                        <td><?php echo e($info["hora_vuelo_salida"]); ?></td>
                        <?php break; ?>
                <?php endswitch; ?>
                <td>
                <a href="<?php echo e(route(Session::get('userroute').'.reservas.ver', ['idreserva' => $info['id_reserva']])); ?>" class="btn btn-outline-success ver_reserva" id="ver_reserva" name="ver_reserva">
                    <img src="<?php echo e(asset('/assets/visibility_FILL0_wght400_GRAD0_opsz24.svg')); ?>">
                </a>
                </td>
                <td>
                    <a href="<?php echo e(route (Session::get('userroute').'.reservas.modificar', ['idreserva' => $info['id_reserva']])); ?>" class="btn btn-outline-primary modificar_reserva" id="modificar_reserva" name="modificar_reserva">
                        <img src="<?php echo e(asset('/assets/edit_FILL0_wght400_GRAD0_opsz24.svg')); ?>">
                    </a>
                </td>
                <td>

                <?php if(Session::get('usertype') == "6"): ?>
                    <?php if(\Carbon\Carbon::now()->diffInHours(\Carbon\Carbon::parse($info["fecha_entrada"])) <= 48 ): ?>
                        <a href="<?php echo e(route (Session::get('userroute').'.reservas.eliminar', ['idreserva' => $info['id_reserva']])); ?>" class="btn btn-outline-danger eliminar_reserva" id="eliminar_reserva" name="eliminar_reserva">
                            <img src="<?php echo e(asset('/assets/delete_FILL0_wght400_GRAD0_opsz24.svg')); ?>">
                        </a>
                    <?php else: ?>
                        <img src="<?php echo e(asset('/assets/delete_FILL0_wght400_GRAD0_opsz24.svg')); ?>">
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route (Session::get('userroute').'.reservas.eliminar', ['idreserva' => $info['id_reserva']])); ?>" class="btn btn-outline-danger eliminar_reserva" id="eliminar_reserva" name="eliminar_reserva">
                        <img src="<?php echo e(asset('/assets/delete_FILL0_wght400_GRAD0_opsz24.svg')); ?>">
                    </a>
                <?php endif; ?>
                        
                    
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/producto3/resources/views/reservas/listados/ver_reservas_total.blade.php ENDPATH**/ ?>