<?php 
    foreach($alertas as $key => $alerta):
        foreach($alerta as $mensaje):
?>
<div class="alert text-center <?php echo $key; ?>"><?php echo $mensaje; ?></div>

<?php
        endforeach;
    endforeach;
?><?php /**PATH /var/www/html/producto3/resources/views/viajero/alertas.blade.php ENDPATH**/ ?>