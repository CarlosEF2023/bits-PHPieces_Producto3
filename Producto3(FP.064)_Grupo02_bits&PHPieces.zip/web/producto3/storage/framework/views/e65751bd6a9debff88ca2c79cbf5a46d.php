
<?php $__env->startSection('title', 'Reservas del Hotel all Aeropuerto'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mt-5">
    <div class="col-md-8">
    <div class="card">

    <div class="phppot-container">
            <h1>Reserva trayecto Aeropuerto al Hotel</h1>

            <form method="POST" name="checkout-form" id="checkout-form" action="<?php echo e(Route(Session::get('userroute').'.reservas.nuevo')); ?>">
            <?php echo csrf_field(); ?>
                <input type="hidden" name="idtiporeserva" id="idtiporeserva" value="3">
                <?php if(Session::get('usertype')=="5"): ?>
                    <input type="hidden" name="idhotelreserva" id="idhotelreserva" value="999">
                <?php else: ?>
                    <input type="hidden" name="idhotelreserva" id="idhotelreserva" value="<?php echo e(Session::get('id')); ?>">
                <?php endif; ?>

                <div class="wizard-flow-chart">
                    <span class="fill">1</span>
                    <span>2</span>
                    <span>3</span>
                    <span>4</span>
                </div>
                <!-- Wizard section 1 -->
                <section id="aeropuerto_hotel">
                    <h3>Recogida aeropuerto</h3>
                    <div class="row">
                        <label class="float-left label-width">Día de llegada</label>
                        <input name="diadellegada" id="diadellegada" type="date" min="<?php echo date('Y-m-d', strtotime('+2 day')); ?>" max="<?php echo date('Y-m-d', strtotime('+15 day')); ?>">
                    </div>
                    <div class="row">
                        <label class="float-left label-width">Hora de llegada</label>
                        <input name="horadellegada" id="horadellegada" type="time">
                    </div>
                    <div class="row">
                        <label class="float-left label-width">Número de vuelo</label>
                        <input name="numerovuelo" id="numerovuelo" type="text">
                    </div>
                    <div class="row">
                        <label class="float-left label-width">Aeropueto Origen</label>
                        <input name="aeropuertoorigen" id="aeropuertoorigen" type="text">
                    </div>
                    <div class="row button-row">
                    <div class="btn-group" role="group">
                        <button class="btn btn-outline-success" type="button" onClick="validate(this)">Siguiente</button>
                        <a href="<?php echo e(back()->getTargetUrl()); ?>" class="btn btn-danger">Cancelar</a>
                    </div>
                    </div>
                </section>

                <!-- Wizard section 2 -->
                <section id="hotel_aeropuerto" class="display-none">
                    <h3>Salida del Hotel</h3>
                    <div class="row">
                        <label class="float-left label-width">Día de salida</label>
                        <input name="diadesalida" id="diadesalida" type="date" min="<?php echo e(\Carbon\Carbon::now()->addDays(2)->format('Y-m-d')); ?>" max="<?php echo e(\Carbon\Carbon::now()->addDays(15)->format('Y-m-d')); ?>">
                    </div>
                    <div class="row">
                        <label class="float-left label-width">Hora de salida</label>
                        <input name="horadesalida" id="horadesalida" type="time">
                    </div>
                    <div class="row">
                        <label class="float-left label-width">Hora de recogida en el Hotel</label>
                        <input name="horaderecogida" id="horaderecogida" type="time">
                    </div>
                    <div class="row">
                        <label class="float-left label-width">Número de vuelo</label>
                        <input name="numerovuelo" id="numerovuelo" type="text">
                    </div>
                    <div class="row">
                        <label class="float-left label-width">Aeropueto Origen</label>
                        <input name="aeropuertoorigen" id="aeropuertoorigen" type="text">
                    </div>
                    <div class="row button-row">
                    <div class="btn-group" role="group">
                        <button class="btn btn-outline-success" type="button" onClick="validate(this)">Siguiente</button>
                        <a href="<?php echo e(back()->getTargetUrl()); ?>" class="btn btn-danger">Cancelar</a>
                    </div>
                    </div>
                </section>

            <!-- Wizard section 3 -->
            <section id="Datos_comunes" class="display-none">
                    <h3>Hotel destino</h3>
                    <div class="row">
                        <label class="float-left label-width">Hotel recogida</label>
                        <?php if(Session::get('usertype')=="5"): ?>
                            <?php if (isset($component)) { $__componentOriginal49377d3340038425e59f0e6f1b90a6b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49377d3340038425e59f0e6f1b90a6b2 = $attributes; } ?>
<?php $component = App\View\Components\HotelSelect::resolve(['selected' => Session::get('id'),'name' => 'Hotel_Destino'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hotel-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HotelSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49377d3340038425e59f0e6f1b90a6b2)): ?>
<?php $attributes = $__attributesOriginal49377d3340038425e59f0e6f1b90a6b2; ?>
<?php unset($__attributesOriginal49377d3340038425e59f0e6f1b90a6b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49377d3340038425e59f0e6f1b90a6b2)): ?>
<?php $component = $__componentOriginal49377d3340038425e59f0e6f1b90a6b2; ?>
<?php unset($__componentOriginal49377d3340038425e59f0e6f1b90a6b2); ?>
<?php endif; ?>
                        <?php else: ?>
                            <?php if (isset($component)) { $__componentOriginal49377d3340038425e59f0e6f1b90a6b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49377d3340038425e59f0e6f1b90a6b2 = $attributes; } ?>
<?php $component = App\View\Components\HotelSelect::resolve(['selected' => 0,'name' => 'Hotel_Destino'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hotel-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HotelSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49377d3340038425e59f0e6f1b90a6b2)): ?>
<?php $attributes = $__attributesOriginal49377d3340038425e59f0e6f1b90a6b2; ?>
<?php unset($__attributesOriginal49377d3340038425e59f0e6f1b90a6b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49377d3340038425e59f0e6f1b90a6b2)): ?>
<?php $component = $__componentOriginal49377d3340038425e59f0e6f1b90a6b2; ?>
<?php unset($__componentOriginal49377d3340038425e59f0e6f1b90a6b2); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <label class="float-left label-width">Número de viajeros</label>
                        <input name="numeroviajeros" id="numeroviajeros" type="number" min="1" max="8">
                    </div>
                    <div class="row">
                        <label class="float-left label-width">email reserva</label>
                        <?php if(Session::get('usertype')!="6"): ?>
                            <input name="emailreserva" id="emailreserva" type="mail" value="">
                        <?php else: ?>
                            <input name="emailreserva" id="emailreserva" type="mail" value="<?php echo e(Session::get('mail')); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="row button-row">
                    <div class="row button-row">
                    <div class="btn-group" role="group">
                        <button class="btn btn-outline-primary" type="button" onClick="showPrevious(this)">Anterior</button>
                        <button class="btn btn-outline-success" type="button" onClick="validate(this)">Siguiente</button>
                        <a href="<?php echo e(back()->getTargetUrl()); ?>" class="btn btn-danger">Cancelar</a>
                        </div>
                    </div>
                </section>


                <!-- Wizard section 4 -->
                <section id="checkin_reserva" class="display-none">
                    <h3>Realizar check-in de la reserva</h3>
                    <div class="card" id="datosreserva" name="datosreserva">
                        <br>
                    </div>
                    <p>Pulse 'Enviar' si está todo correcto.<br>En breve recibirá un mail con los datos de la reserva.</p>
                    <div class="row button-row">
                        <div class="btn-group" role="group">
                        <button class="btn btn-outline-primary" type="button" onClick="showPrevious(this)">Anterior</button>
                        <button class="btn btn-outline-success" type="submit">Enviar</button>
                        <a href="<?php echo e(back()->getTargetUrl()); ?>" class="btn btn-danger">Cancelar</a>
                    </div>
                    </div>
                </section>
            </form>
        </div>
        </div>
  </div>
</div>


<div class="modal" name="myModal" id="myModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <form name="formulario_modal">
            <h5 class="modal-title" name="titulo_modal"id="titulo_modal">Validar reserva</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" name="cuerpo_modal" id="cuerpo_modal">
            <p>Modal body text goes here.</p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cerrar</button>
            <button type="button" class="btn btn-outline-primary" name="aceptarmodal" id="aceptarmodal">Validar</button>
            <a href="<?php echo e(back()->getTargetUrl()); ?>" class="btn btn-primary">Volver</a>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/producto3/resources/views//reservas/completo/crear_reservacompleto.blade.php ENDPATH**/ ?>