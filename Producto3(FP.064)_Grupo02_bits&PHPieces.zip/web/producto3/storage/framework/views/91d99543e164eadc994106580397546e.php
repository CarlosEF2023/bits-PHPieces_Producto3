<nav class="navbar navbar-expand-lg navbar-light bg-dark navbar-dark shadow">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <span><img src="<?php echo e(asset('assets/Isla_Transfers_Logo.jpeg')); ?>" width="64px" height="64px"></span>
        </a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-content">
            <div class="hamburger-toggle">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </button>

        <?php if(isset($user)): ?>
        <!-- Si existe el usuario -->
        <div class="collapse navbar-collapse" id="navbar-content">
            <ul class="navbar-nav mr-auto mb-2 mb-lg-0">

                <li class="nav-item"><a class="nav-link active" aria-current="page" href="#">Isla Transfer</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Hola <?php echo e($user->email); ?>!</a></li>

              <?php switch($user->Id_tipo_usuario):

                    case ('3'): ?>
                        <!-- Administración -->
                        
                        <li class="nav-item"><a class="nav-link" href="">Crear Reservas</a></li>
                        
                        <li class="nav-item"><a class="nav-link" href="">Listar Reservas</a></li>
                        
                        <li class="nav-item"><a class="nav-link" href="">Datos personales</a></li>
                        <?php break; ?>

                    <?php case ('4'): ?>
                    <!-- Conductor -->
                    
                    <?php break; ?>

                    <?php case ('5'): ?>
                    <!-- Hotel -->
                    <!-- Aquí colocar las opciones específicas para el hotel -->
                    <?php break; ?>

                    <?php case ('6'): ?>
                    <!-- Viajero -->
                    
                        <li class="nav-item"><a class="nav-link" href="">Crear Reservas</a></li>
                        
                        <li class="nav-item"><a class="nav-link" href="">Listar Reservas</a></li>
                        
                        <li class="nav-item"><a class="nav-link" href="cambiar-datos">Datos personales</a></li>
                    <?php break; ?>

                <?php endswitch; ?> 

            </ul>

            <a class="nav-link" style="align:right;" href="#" id="cerraraplicacion" name="cerraraplicacion">Salir</a>

        </div>
        <!-- Fin de div collapse -->

        <?php else: ?>

        <!-- Si no existe el usuario -->
        <div class="collapse navbar-collapse" id="navbar-content">
            <ul class="navbar-nav mr-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="./views/principal.php">Isla Transfer</a>
                </li>
            </ul>
        </div>

        <!-- Colapsar correctamente los form de login -->
        <div>
            <form action="<?php echo e(route('login')); ?>" method="post" style="display: flex; align-items: center;">
                <?php echo csrf_field(); ?>
                <div style="margin-right: 10px;">
                    <a href="registrarse" class="enlace">Registrarse</a>
                </div>
                <div style="margin-right: 10px;">
                    <label for="email">@</label>
                    <input type="email" id="emailId" name="email" placeholder="email" required>
                </div>
                <div>
                    <label for="password"></label>
                    <input type="password" id="passwordId" name="password" placeholder="password" required>
                </div>
                <div style="margin-left: 10px;">
                    <input type="submit" value="Login" class="btn btn-secondary btn-sm">
                </div>
            </form>
        </div>
        </nav>
        </div>
        <?php endif; ?>
        <br>
<?php /**PATH /var/www/html/producto3/resources/views/layouts/menu_nav.blade.php ENDPATH**/ ?>