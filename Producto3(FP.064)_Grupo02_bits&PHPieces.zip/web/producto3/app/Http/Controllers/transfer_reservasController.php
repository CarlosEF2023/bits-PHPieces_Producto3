<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class transfer_reservasController extends Controller
{
    //
}
