@extends('layouts.plantilla')
@section('title', 'Menú de listado de reservas')

@section("nav")
@include('layouts.menu_nav')
@endsection

@section('content')
<h1>Viajero</h1>

@endsection