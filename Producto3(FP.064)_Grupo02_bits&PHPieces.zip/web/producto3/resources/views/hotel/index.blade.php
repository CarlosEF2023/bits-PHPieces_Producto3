@extends('layouts.plantilla')
@section('title', 'Menú de listado de reservas')

@section("nav")
@include('layouts.menu_nav')
@endsection

@section('content')
<h1>Hotel</h1>

@endsection